

function increment ( entier ){
    entier++
}   

let nombre = 0;
increment( nombre );
console.log(nombre); // 0





function inc( tab ){
    tab[0]++
}

let tableau = [0];
inc(tableau);
console.log(tableau[0]) //